library(tesseract)
full.text <- NULL
for(i in 1:1){
  current.text <- tesseract::ocr(paste("Logs2019OCR_", i+1, ".png", sep=""))
  full.text <- paste(full.text,current.text)
}
cat(full.text)
